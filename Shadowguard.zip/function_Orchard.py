from System.Collections.Generic import List
from System import Byte, Int32

######################
#Shadow Guard
#By Guinea Worm
#Orchard, Bar
#v5 11/16/2023 @ 1100            
######################

def orchard():
    items = []
    ignore1 = []
    ignore2 = []
    ignore = []
    picked = False
    complete = True
    Journal.Clear()
    
    theFilter = Items.Filter()
    theFilter.RangeMax = 25
    theFilter.OnGround = True
    theFilter.Enabled = True
    theFilter.Movable = False
    trees = List[Int32]([0xD01])
    theFilter.Graphics = trees
    
    itemsInRange = Items.ApplyFilter(theFilter)
    
    while len(itemsInRange) != len(ignore1):
        Player.HeadMessage(55,"Orchard Start")
        for x in itemsInRange:
            if x.Serial not in items and "cypress tree" in x.Name and x.Serial not in ignore1:
                items.Add(x.Serial)
                ignore1.Add(x.Serial)
        items = sorted(items, key=lambda itm: itm)
        #reset hue every time???
        bool = False
        hue = 0
        num = 0
        while bool == False:
            for x in range(len(items)):
                Items.SetColor(items[x],hue)
                num = num + 1
                if num == 2:
                    num = 0
                    hue = (x+6) * 6
            bool = True
        complete = False

    while complete == False:
        treeInRange = Items.ApplyFilter(theFilter)
        Misc.Pause(100)
        for tree in range(len(treeInRange)):
            if picked == False and Player.DistanceTo(treeInRange[tree]) < 4 and treeInRange[tree].Serial not in ignore2:
                treeColor = treeInRange[tree].Hue
                Items.UseItem(treeInRange[tree])
                Misc.Pause(100)
                if Items.BackpackCount(0x09D0,-1) > 0:
                    ignore2.Add(treeInRange[tree].Serial)
                    Player.HeadMessage(55,"Pick")
                    Items.SetColor(Items.FindByID(0x09D0,-1,Player.Backpack.Serial,False,False).Serial,treeColor)
                    picked = True
            if picked == True and Player.DistanceTo(treeInRange[tree]) < 10 and treeInRange[tree].Hue == treeColor and treeInRange[tree].Serial not in ignore2:
                Player.HeadMessage(55,"Throw")
                Items.UseItem(Items.FindByID(0x09D0,-1,Player.Backpack.Serial,False,False))
                Misc.Pause(100)
                Target.TargetExecute(treeInRange[tree].Serial)
                Misc.Pause(100)
                if Items.BackpackCount(0x09D0,-1) > 0:
                    ignore2.Add(treeInRange[tree])
                    Misc.Pause(1100)
                    picked = False
        if Journal.SearchByType("You have bested this tower",'System'):
            Player.HeadMessage(55,"Huzzah!")
            complete = True

def bar():
    mobile = Mobiles.Filter()
    mobile.Enabled = True
    mobile.Notorieties = List[Byte](bytes([6]))
    mobile.RangeMax = 10
    
    filter = Items.Filter()
    filter.Enabled = True
    filter.Name = 'A Bottle of Liquor'
    filter.RangeMax = 2

    mobiles = Mobiles.ApplyFilter(mobile)
    if len(mobiles) > 0:
        Player.HeadMessage(255,"We are at the bar boys!")        
        complete = False
        while complete == False:
            list = Items.ApplyFilter(filter)
            for item in list:
                Items.UseItem(item)
                Target.WaitForTarget(500)
                mobiles = Mobiles.ApplyFilter(mobile)
                if len(mobiles) > 0:
                    Target.TargetExecute(mobiles[0])
            if Journal.SearchByType("You have bested this tower",'System'):
                Player.HeadMessage(55,"Huzzah!")
                complete = True            
    
while True:
    orchard()
    bar()
    Misc.Pause(1000)

#lambda test.....
#items = [3, 4, 1, 7]
#Player.HeadMessage(52, str(items))
#lambda test.....